import type { NextRequest } from "next/server"

// Simple in-memory storage for backup streams
// In a production app, you would use a database
const backupStreamsStore: Record<string, { url: string; priority: number }[]> = {}

// Helper function to decode base64-encoded strings
const safeDecode = (encodedString: string): string => {
  try {
    // Validate that the string contains only hex characters
    if (!/^[0-9a-f]*$/.test(encodedString)) {
      console.warn("Invalid hex string:", encodedString)
      return encodedString
    }

    // Convert hex pairs back to characters
    let result = ""
    for (let i = 0; i < encodedString.length; i += 2) {
      if (i + 1 < encodedString.length) {
        const hexPair = encodedString.substring(i, i + 2)
        const charCode = Number.parseInt(hexPair, 16)
        result += String.fromCharCode(charCode)
      }
    }

    console.log(`Decoded "${encodedString}" to "${result}"`)
    return result
  } catch (error) {
    console.error("Error decoding string:", error, "Original:", encodedString)
    // Return the original string if decoding fails
    return encodedString
  }
}

export async function GET(request: NextRequest) {
  const channelId = request.nextUrl.searchParams.get("channelId")

  if (!channelId) {
    return Response.json({ error: "Missing channelId parameter" }, { status: 400 })
  }

  try {
    console.log(`Original channelId: ${channelId}`)

    // Try to decode using base64 decoding
    const decodedChannelId = safeDecode(channelId)
    console.log(`Decoded channel ID: ${decodedChannelId}`)

    const backupStreams = backupStreamsStore[decodedChannelId] || []
    return Response.json({ backupStreams })
  } catch (error) {
    console.error("Error retrieving backup streams:", error)
    return Response.json(
      {
        error: "Failed to retrieve backup streams",
        message: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const { channelId, streams } = await request.json()

    if (!channelId) {
      return Response.json({ error: "Missing channelId parameter" }, { status: 400 })
    }

    if (!Array.isArray(streams)) {
      return Response.json({ error: "Streams must be an array" }, { status: 400 })
    }

    // Validate stream URLs
    const validStreams = streams.filter((stream) => {
      try {
        // Basic URL validation
        return typeof stream.url === "string" && stream.url.trim() !== "" && stream.url.includes("://")
      } catch (e) {
        return false
      }
    })

    // Store the backup streams
    backupStreamsStore[channelId] = validStreams.map((stream: any, index: number) => ({
      url: stream.url,
      priority: stream.priority || index + 1,
    }))

    // Return the updated store for debugging
    return Response.json({
      success: true,
      backupStreams: backupStreamsStore[channelId],
      channelId,
    })
  } catch (error) {
    console.error("Error saving backup streams:", error)
    return Response.json(
      {
        error: "Failed to save backup streams",
        message: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}

// Export the store for use in other routes
export { backupStreamsStore }
