import type { NextRequest } from "next/server"

// Simple in-memory storage for image detection settings
// In a production app, you would use a database
const imageDetectionStore: Record<
  string,
  {
    enabled: boolean
    referenceImageUrl?: string
    similarityThreshold: number
    checkInterval: number
  }
> = {}

// Helper function to decode base64-encoded strings
const safeDecode = (encodedString: string): string => {
  try {
    // Validate that the string contains only hex characters
    if (!/^[0-9a-f]*$/.test(encodedString)) {
      console.warn("Invalid hex string:", encodedString)
      return encodedString
    }

    // Convert hex pairs back to characters
    let result = ""
    for (let i = 0; i < encodedString.length; i += 2) {
      if (i + 1 < encodedString.length) {
        const hexPair = encodedString.substring(i, i + 2)
        const charCode = Number.parseInt(hexPair, 16)
        result += String.fromCharCode(charCode)
      }
    }

    console.log(`Decoded "${encodedString}" to "${result}"`)
    return result
  } catch (error) {
    console.error("Error decoding string:", error, "Original:", encodedString)
    // Return the original string if decoding fails
    return encodedString
  }
}

export async function GET(request: NextRequest) {
  const channelId = request.nextUrl.searchParams.get("channelId")

  if (!channelId) {
    return Response.json({ error: "Missing channelId parameter" }, { status: 400 })
  }

  try {
    console.log(`Original channelId: ${channelId}`)

    // Try to decode using base64 decoding
    const decodedChannelId = safeDecode(channelId)
    console.log(`Decoded channel ID: ${decodedChannelId}`)

    const settings = imageDetectionStore[decodedChannelId] || {
      enabled: false,
      similarityThreshold: 85,
      checkInterval: 10,
    }
    return Response.json({ settings })
  } catch (error) {
    console.error("Error retrieving image detection settings:", error)
    return Response.json(
      {
        error: "Failed to retrieve image detection settings",
        message: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const { channelId, settings } = await request.json()

    if (!channelId) {
      return Response.json({ error: "Missing channelId parameter" }, { status: 400 })
    }

    if (!settings) {
      return Response.json({ error: "Missing settings" }, { status: 400 })
    }

    // Validate settings
    const validatedSettings = {
      enabled: Boolean(settings.enabled),
      referenceImageUrl: settings.referenceImageUrl || "",
      similarityThreshold: Math.min(Math.max(Number(settings.similarityThreshold) || 85, 50), 100),
      checkInterval: Math.min(Math.max(Number(settings.checkInterval) || 10, 5), 60),
    }

    // Store the settings
    imageDetectionStore[channelId] = validatedSettings

    // Return the updated store for debugging
    return Response.json({
      success: true,
      settings: imageDetectionStore[channelId],
      channelId,
    })
  } catch (error) {
    console.error("Error saving image detection settings:", error)
    return Response.json(
      {
        error: "Failed to save image detection settings",
        message: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}

// Export the store for use in other routes
export { imageDetectionStore }
